//Dharani Ceations 
int Bulb = 3; 
int PIR = 2; 
int val = 0; 

void setup() 
{
pinMode(Bulb, OUTPUT); 
pinMode(PIR, INPUT); 
}
void loop(){
val = digitalRead(PIR); 
if (val == HIGH) { 
digitalWrite(Bulb, LOW); 
delay(1000);
} 
else 
{
digitalWrite(Bulb, HIGH); 
delay(2000);
 }
}